using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Lista : MonoBehaviour
{
    [SerializeField] List<Objects> objectList;
    [SerializeField] GameObject Inventoryslot;


    private void Start()
    {
        for (int i = 0; i < 10; i++) 
        {
            


             
        }
    }


    // Update is called once per frame
    void Update()
    {
        
    }
}
